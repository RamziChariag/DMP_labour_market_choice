# Changes applied (identification action plan)

Static edits only — **no Julia was available in the editing environment, so nothing was run.**
The codebase is edited and statically consistent (`MOMENT_NAMES` is byte-identical at 26 across
`data_processing/setup.jl` and `smm/moments.jl`; the new objects round-trip and labels are clean),
but must be run/verified per `TODO_roadmap.md` Phase 0.

## Summary of the change

- σ_w is now **calibrated** from one reliability knob `λ_w` (default 0.82), pinned like r/ν/φ.
- β_U, β_S are now **free**; η_U, η_S stay fixed at 0.5; ξ_S stays free in every window.
- `wage_premium`, `ur_total` are **skipped** (weight 0) — not deleted.
- New moments: `overlap_UgtS`, `overlap_SltU` (cross-market wage overlap) and `ltu_share_S`
  (skilled long-term-unemployment share), appended to `MOMENT_NAMES` (→ 26; 24 active).
- `ρ_NILF` (gross skilled U→NILF hazard) added as the LTU competing-risk input.
- Parameter labels: "/A" removed (LMR-style plain names); the math is unchanged.
- `ν_ub` comment contradiction fixed (it is a lower bound).

## Per file

**solver/params.jl** — `SkilledParams` gains `ρ_NILF::Float64 = 0.03` (empirical alignment input; not
part of the solve; placeholder until `rho_nilf.csv` supplies the measured value).

**solver/equilibrium.jl** — unpacks `ρ_NILF`; computes `ltu_share_S` = u_S-weighted mixture-of-
exponentials survivor at `a* = 27·12/52` with `δS_unemp = κS·(1−Γ(p*_S)) + ρ_NILF`; returns it.

**smm/moments.jl** — `MOMENT_NAMES` → 26 (assert 26). New `_logwage_conv_cdf` helper. `model_moments`
computes `overlap_UgtS = 1 − F_U^conv(p50_wage_S)`, `overlap_SltU = F_S^conv(p50_wage_U)`, reads
`obj.ltu_share_S`, and returns all three.

**smm/smm_params.jl** — labels drop "/A" (b_U, b_T, b_S, k_U, k_S, σ_S); bU/bT/bS comment states the
A-normalization once. `SMMRunParams` gains `λ_w::Float64 = 0.82` (printed in the run header only).
New `calibrate_sigma_w(λ_w, moments)`. `unpack_θ` threads `ρ_NILF` (first pass, `sp_fields`, final
struct) so `:skl_ρ_NILF` is injectable via `fixed`.

**smm/smm_main.jl** — `FIX_PARAMS`: keep η, drop β (freed). `SKIP_MOMENTS = [:wage_premium, :ur_total]`.
`const LAMBDA_W = 0.82`. After moments load: `calibrate_sigma_w` → σ_wU/σ_wS injected as
`unsk_σ_w`/`skl_σ_w`; `_load_rho_nilf` reads `rho_nilf.csv` (crisis→baseline) and injects
`skl_ρ_NILF` when present. Free counts: baseline 22, crisis 17 (σ_w auto-dropped by the `fixed` filter;
β stays free).

**data_processing/cps_basic.jl** — `:DURUNEMP` added to `cols_to_keep`.

**data_processing/transitions.jl** — `ν_ub` → `ν_lb` (lower bound) with corrected comments and check
direction; adds gross skilled U→NILF hazard `ρ_NILF` and writes `rho_nilf.csv`.

**data_processing/moments.jl** — adds `ltu_share_S` (CPS: WTFINL-weighted skilled-unemployed share with
`DURUNEMP ≥ 27`, monthly-then-averaged) and the overlap pair (ASEC: year-then-averaged shares); 23→26.

**data_processing/sigma.jl** — Σ̂ influence-function columns for the three new moments, using the file's
uniform per-period-deviation ψ convention (23×23 → 26×26). *Note:* the analytic two-sample/ratio IFs
(action plan Part C) are documented in the data appendix, not implemented, so Σ̂ stays homogeneous;
this is immaterial under equal weights.

**data_processing/setup.jl** — `MOMENT_NAMES` → 26 (assert 26).

**data_processing/validation.jl** — TODO for published benchmark ranges of the 3 new moments.

**data_processing/data_processing_main.jl** — banners/driver listing updated (23→26, `rho_nilf.csv`).

**transition/plots_and_tables.jl** — 3 new moments added to display maps (via `get`, safe). TODO:
regenerate `DEEP_STRUCTURAL`/`REGIME_SPECIFIC` display lists for β-free / σ_w-calibrated (cosmetic).

**transition/transition_params.jl** — no display labels present; no change needed (confirmed).

## Open TODOs (see TODO_roadmap.md)
`ρ_NILF` value via `rho_nilf.csv`; the Σ̂ IF convention decision; the `transition/` display-list
regeneration; `validation.jl` benchmark ranges.
